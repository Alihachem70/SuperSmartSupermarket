<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function users(Request $request)
    {
        // 1 returns admin and owners, anything else returns customer only
        $get_users = $request->query("get_users");

        $users_query = User::query();

        if ($get_users === "1") {
            $users = $users_query->where("role_as", 1);
        } else {
            $users = $users_query->where("role_as", 0);
        }

        $users = $users_query->get();

        return response()->json([
            'results' => $users
        ], 200);
    }

    public function viewUser($id)
    {
        $users = User::find($id);
        return response()->json([
            'results' => $users
        ], 200);
    }
}
