<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        return response()->json([
            'results' => $categories
        ], 200);
    }

    public function insert(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:255', 'unique:categories'],
            'description' => ['required', 'string', 'max:65535'],
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
        ], [
            'name.required' => 'The name field is required.',
            'name.string' => 'The name must be a string.',
            'name.max' => 'The name may not be greater than 255 characters.',
            'name.unique' => 'This name has already been taken.',
            'description.required' => 'The description field is required.',
            'description.string' => 'The description must be a string.',
            'description.max' => 'The description may not be greater than 255 characters.',
            'image.required' => 'The image field is required.',
            'image.image' => 'The image must be an image file.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $category = new Category();

        if ($request->hasFile('image')) {
            $fileNameWithExt = $request->file('image')->getClientOriginalName();
            $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
            $fileExt = $request->file('image')->getClientOriginalExtension();
            $fileNameToStore = $fileName . '_' . time() . '.' . $fileExt;
            $request->file('image')->move(public_path('assets/uploads/category/'), $fileNameToStore);
            $category->image = $fileNameToStore;
        }

        $category->name = $request->input('name');
        $category->slug = $request->input('name');
        $category->description = $request->input('description');
        $category->popular = $request->input('popular');
        $category->save();

        return response()->json([
            'name' => $category->name,
            'slug' => $category->slug,
            'description' => $category->description,
            'popular' => $category->popular,
        ], 201);
    }

    public function retrieve($id)
    {
        $category = Category::find($id);
        return response()->json([
            'results' => $category
        ], 200);
    }


    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => ['sometimes', 'required', 'string', 'max:255', 'unique:categories,name,' . $id],
            'description' => ['sometimes', 'required', 'string', 'max:65535'],
            'image' => 'sometimes|nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048'
        ], [
            'name.required' => 'The name field is required.',
            'name.string' => 'The name must be a string.',
            'name.max' => 'The name may not be greater than 255 characters.',
            'name.unique' => 'This name has already been taken.',
            'description.required' => 'The description field is required.',
            'description.string' => 'The description must be a string.',
            'description.max' => 'The description may not be greater than 255 characters.',
            'image.image' => 'The image must be an image file.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $category = Category::find($id);
        if ($request->hasFile('image')) {
            $path = 'assets/uploads/category/' . $category->image;
            if (File::exists($path)) {
                File::delete($path);
            }
            $file = $request->file('image');
            $ext = $file->getClientOriginalExtension();
            $filename = time() . '.' . $ext;
            $file->move('assets/uploads/category', $filename);
            $category->image = $filename;
        }

        $category->name = $request->input('name');
        $category->slug = $request->input('name');
        $category->description = $request->input('description');
        $category->popular = $request->input('popular');

        $category->update();
        return response()->json([
            'results' => $category
        ], 200);
    }

    public function destroy($id)
    {
        $category = Category::find($id);
        if ($category->image) {
            $path = 'assets/uploads/category/' . $category->image;
            if (File::exists($path)) {
                File::delete($path);
            }
        }
        $category->delete();
        return response()->json([
            'results' => 'Category deleted successfully'
        ], 200);
    }
}
