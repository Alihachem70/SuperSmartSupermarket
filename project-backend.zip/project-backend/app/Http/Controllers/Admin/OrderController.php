<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::where('status', '0')->get();
        return response()->json([
            'results' => $orders
        ], 200);
    }

    public function view($id)
    {
        $order = Order::where('id', $id)->first();
        $order->load('orderitems', 'orderitems.products');
        // $order->orderitems.load('products');
        return response()->json([
            'results' => $order
        ], 200);
    }

    public function updateOrder(Request $request, $id)
    {
        $order = Order::find($id);
        $order->status = $request->input('order_status');
        $order->update();
        return response()->json([
            'results' => $order
        ], 200);
    }

    public function orderHistory()
    {
        $orders = Order::where('status', '1')->get();
        return response()->json([
            'results' => $orders
        ], 200);
    }
}
