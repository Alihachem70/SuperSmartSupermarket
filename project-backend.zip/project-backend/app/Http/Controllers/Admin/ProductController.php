<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Laptop;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Illuminate\Contracts\Validation\Rule;

class ProductController extends Controller
{
    //
    public function index()
    {
        $products = Product::all();
        $products->load('category');

        return response()->json([
            'results' => $products
        ], 200);
    }

    public function insert(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'cate_id' => ['required', 'integer', 'exists:categories,id'],
            'name' => ['required', 'string', 'max:255', "unique:products,name,NULL,id,deleted_at,NULL"],
            'brand' => ['required', 'string', 'max:255'],
            'small_description' => ['required', 'string', 'max:65535'],
            'description' => ['required', 'string', 'max:65535'],
            'original_price' => ['required', 'integer', 'min:0'],
            'discount_price' => ['sometimes', 'required', 'integer', 'min:0'],
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
            'qty' => ['required', 'integer', 'min:0'],
        ], [
            'cate_id.required' => 'The category ID field is required.',
            'cate_id.integer' => 'The category ID must be an integer.',
            'cate_id.exists' => 'The selected category ID is invalid.',
            'name.required' => 'The name field is required.',
            'name.string' => 'The name must be a string.',
            'name.max' => 'The name may not be greater than 255 characters.',
            'name.unique' => 'The name has already been taken.',
            'brand.required' => 'The brand field is required.',
            'brand.string' => 'The brand must be a string.',
            'brand.max' => 'The brand may not be greater than 255 characters.',
            'small_description.required' => 'The small description field is required.',
            'small_description.string' => 'The small description must be a string.',
            'small_description.max' => 'The small description may not be greater than 65535 characters.',
            'description.required' => 'The description field is required.',
            'description.string' => 'The description must be a string.',
            'description.max' => 'The description may not be greater than 65535 characters.',
            'original_price.required' => 'The Original price field is required.',
            'original_price.integer' => 'The Original price must be an integer.',
            'original_price.min' => 'The Original price may not be less than 0.',
            'discount_price.required' => 'The Discount price field is required.',
            'discount_price.integer' => 'The Discount price must be an integer.',
            'discount_price.min' => 'The Discount price may not be less than 0.',
            'image.image' => 'The image must be an image file.',
            'qty.required' => 'The quantity field is required.',
            'qty.integer' => 'The quantity must be an integer.',
            'qty.min' => 'The quantity may not be less than 0.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $product = new Product();

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $ext = $file->getClientOriginalExtension();
            $filename = time() . '.' . $ext;
            $file->move('assets/uploads/products', $filename);
            $product->image = $filename;
        }
        $cate_id = $request->input('cate_id');
        $product->cate_id = $cate_id;
        $product->name = $request->input('name');
        $product->slug = $request->input('name');
        $product->brand = $request->input('brand');
        $product->small_description = $request->input('small_description');
        $product->description = $request->input('description');
        $product->original_price = $request->input('original_price');
        $product->discount_price = $request->input('discount_price');
        $product->qty = $request->input('qty');
        $product->hidden = $request->input('hidden');
        $product->trending = $request->input('trending');
        $product->show_in_carousel = $request->input('show_in_carousel');

        $product->save();

        $category = Category::find($cate_id);
        if ($category->name == "Laptops") {
            $laptop = new Laptop();

            $laptop->prod_id = $product->id;
            $laptop->motherboard = $request->input('motherboard');
            $laptop->cpu = $request->input('cpu');
            $laptop->gpu = $request->input('gpu');
            $laptop->display_size = $request->input('display_size');
            $laptop->ssd = $request->input('ssd');
            $laptop->hdd = $request->input('hdd');
            $laptop->ram = $request->input('ram');

            $laptop->save();
        }

        return response()->json([], 201);
    }

    public function retrieve($id)
    {
        $product = Product::find($id);
        $product->load('category');
        return response()->json([
            'results' => $product
        ], 200);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'cate_id' => ['sometimes', 'required', 'integer', 'exists:categories,id'],
            'name' => ['sometimes', 'required', 'string', 'max:255', "unique:products,name,$id,id,deleted_at,NULL"],
            'brand' => ['sometimes', 'required', 'string', 'max:255'],
            'small_description' => ['sometimes', 'required', 'string', 'max:65535'],
            'description' => ['sometimes', 'required', 'string', 'max:65535'],
            'original_price' => ['sometimes', 'required', 'integer', 'min:0'],
            'discount_price' => ['sometimes', 'required', 'integer', 'min:0'],
            'image' => 'sometimes|nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
            'qty' => ['sometimes', 'required', 'integer', 'min:0'],
        ], [
            'cate_id.required' => 'The category ID field is required.',
            'cate_id.integer' => 'The category ID must be an integer.',
            'cate_id.exists' => 'The selected category ID is invalid.',
            'name.required' => 'The name field is required.',
            'name.string' => 'The name must be a string.',
            'name.max' => 'The name may not be greater than 255 characters.',
            'name.unique' => 'The name has already been taken.',
            'brand.required' => 'The brand field is required.',
            'brand.string' => 'The brand must be a string.',
            'brand.max' => 'The brand may not be greater than 255 characters.',
            'small_description.required' => 'The small description field is required.',
            'small_description.string' => 'The small description must be a string.',
            'small_description.max' => 'The small description may not be greater than 65535 characters.',
            'description.required' => 'The description field is required.',
            'description.string' => 'The description must be a string.',
            'description.max' => 'The description may not be greater than 65535 characters.',
            'original_price.required' => 'The Original price field is required.',
            'original_price.integer' => 'The Original price must be an integer.',
            'original_price.min' => 'The Original price may not be less than 0.',
            'discount_price.required' => 'The Discount price field is required.',
            'discount_price.integer' => 'The Discount price must be an integer.',
            'discount_price.min' => 'The Discount price may not be less than 0.',
            'image.image' => 'The image must be an image file.',
            'qty.required' => 'The quantity field is required.',
            'qty.integer' => 'The quantity must be an integer.',
            'qty.min' => 'The quantity may not be less than 0.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $product = Product::find($id);

        if ($request->hasFile('image')) {
            $path = 'assets/uploads/products/' . $product->image;
            if (File::exists($path)) {
                File::delete($path);
            }
            $file = $request->file('image');
            $ext = $file->getClientOriginalExtension();
            $filename = time() . '.' . $ext;
            $file->move('assets/uploads/products', $filename);
            $product->image = $filename;
        }

        $product->name = $request->input('name');
        $product->slug = $request->input('name');
        $product->brand = $request->input('brand');
        $product->small_description = $request->input('small_description');
        $product->description = $request->input('description');
        $product->original_price = $request->input('original_price');
        $product->discount_price = $request->input('discount_price');
        $product->qty = $request->input('qty');
        $product->hidden = $request->input('hidden');
        $product->trending = $request->input('trending');
        $product->show_in_carousel = $request->input('show_in_carousel');
        $product->save();

        $cate_id = $request->input('cate_id');
        $category = Category::find($cate_id);
        if ($category->name == "Laptops") {
            $laptop = Laptop::where('prod_id', $product->id)->first();

            $laptop->prod_id = $product->id;
            $laptop->motherboard = $request->input('motherboard');
            $laptop->cpu = $request->input('cpu');
            $laptop->gpu = $request->input('gpu');
            $laptop->display_size = $request->input('display_size');
            $laptop->ssd = $request->input('ssd');
            $laptop->hdd = $request->input('hdd');
            $laptop->ram = $request->input('ram');

            $laptop->save();
        }


        return response()->json([
            'results' => $product
        ], 200);
    }

    public function destroy($id)
    {
        $product = Product::find($id);

        // $path = 'assets/uploads/products/' . $product->image;
        // if (File::exists($path)) {
        //     File::delete($path);
        // }
        $product->delete();

        return response()->json([
            'results' => 'Product Deleted Succesfully'
        ], 200);
    }
}
