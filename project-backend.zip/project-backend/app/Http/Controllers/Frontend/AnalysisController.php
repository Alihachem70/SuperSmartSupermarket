<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Models\Wishlist;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AnalysisController extends Controller
{
    public function adminAnalysis()
    {
        $users_count = User::count();
        $products_count = Product::count();
        $categories_count = Category::count();
        $orders_count = Order::count();
        $completed_orders_count = Order::where("status", "1")->count();
        $pending_orders_count = Order::where("status", "0")->count();

        $data = [
            'users_count' => $users_count,
            'products_count' => $products_count,
            'categories_count' => $categories_count,
            'orders_count' => $orders_count,
            'completed_orders_count' => $completed_orders_count,
            'pending_orders_count' => $pending_orders_count,
        ];

        return response()->json([
            'results' => $data
        ], 200);
    }

    public function userAnalysis()
    {
        $user = Auth::user();

        $orders_count = Order::where("user_id", $user->id)->count();
        $completed_orders_count = Order::where("user_id", $user->id)->where("status", "1")->count();
        $pending_orders_count = Order::where("user_id", $user->id)->where("status", "0")->count();
        $cart_count = Cart::where("user_id", $user->id)->count();
        $wishlist_count = Wishlist::where("user_id", $user->id)->count();

        $data = [
            'orders_count' => $orders_count,
            'completed_orders_count' => $completed_orders_count,
            'pending_orders_count' => $pending_orders_count,
            'cart_count' => $cart_count,
            'wishlist_count' => $wishlist_count,
        ];

        return response()->json([
            'results' => $data
        ], 200);
    }
}
