<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Laptop;
use Illuminate\Http\Request;

class LaptopController extends Controller
{
    public function retrieve(Request $request)
    {
        $product_id = $request->query('product');
        $laptop = Laptop::where('prod_id', $product_id)->first();
        return response()->json([
            'results' => $laptop
        ], 200);
    }
    public function specsList()
    {
        $motherboards = Laptop::select("motherboard")->distinct()->get()->pluck('motherboard');
        $cpu = Laptop::select("cpu")->distinct()->get()->pluck('cpu');
        $gpu = Laptop::select("gpu")->distinct()->get()->pluck('gpu');
        $display_size = Laptop::select("display_size")->distinct()->get()->pluck('display_size');
        $ssd = Laptop::select("ssd")->distinct()->get()->pluck('ssd');
        $hdd = Laptop::select("hdd")->distinct()->get()->pluck('hdd');
        $ram = Laptop::select("ram")->distinct()->get()->pluck('ram');
        $data = [
            'motherboards' => $motherboards,
            'cpu' => $cpu,
            'gpu' => $gpu,
            'display_size' => $display_size,
            'ssd' => $ssd,
            'hdd' => $hdd,
            'ram' => $ram,
        ];
        return response()->json([
            'results' => $data
        ], 200);
    }
}
