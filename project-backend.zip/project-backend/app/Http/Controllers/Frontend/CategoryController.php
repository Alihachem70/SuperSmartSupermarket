<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Laptop;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    public function trendingCategories()
    {
        $trending_categories = Category::where('popular', '1')->take(10)->get();
        return response()->json([
            'results' => $trending_categories
        ], 200);
    }

    public function categories()
    {
        $categories = Category::get();
        return response()->json([
            'results' => $categories
        ], 200);
    }

    public function productsOfCategory(Request $request, $cate_slug)
    {
        $validator = Validator::make($request->all(), [
            'brand' => ['sometimes', 'string', 'max:255'],
            'min_price' => ['sometimes', 'integer', 'min:0'],
            'max_price' => ['sometimes', 'integer', 'min:0'],
            'cpu' => ['sometimes', 'string', 'max:255'],
            'display_size' => ['sometimes', 'string', 'max:255'],
            'gpu' => ['sometimes', 'string', 'max:255'],
            'hdd' => ['sometimes', 'string', 'max:255'],
            'motherboards' => ['sometimes', 'string', 'max:255'],
            'ram' => ['sometimes', 'string', 'max:255'],
            'ssd' => ['sometimes', 'string', 'max:255'],
        ], [
            'brand.string' => 'The brand must be a string.',
            'brand.max' => 'The brand may not be greater than 255 characters.',
            'min_price.integer' => 'The minimum price must be an integer.',
            'min_price.min' => 'The minimum price must be at least 0.',
            'max_price.integer' => 'The max price must be an integer.',
            'max_price.min' => 'The max price must be at least 0.',
            'cpu.string' => 'The cpu must be a string.',
            'cpu.max' => 'The cpu may not be greater than 255 characters.',
            'display_size.string' => 'The display_size must be a string.',
            'display_size.max' => 'The display_size may not be greater than 255 characters.',
            'gpu.string' => 'The gpu must be a string.',
            'gpu.max' => 'The gpu may not be greater than 255 characters.',
            'hdd.string' => 'The hdd must be a string.',
            'hdd.max' => 'The hdd may not be greater than 255 characters.',
            'motherboards.string' => 'The motherboards must be a string.',
            'motherboards.max' => 'The motherboards may not be greater than 255 characters.',
            'ram.string' => 'The ram must be a string.',
            'ram.max' => 'The ram may not be greater than 255 characters.',
            'ssd.string' => 'The ssd must be a string.',
            'ssd.max' => 'The ssd may not be greater than 255 characters.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $product_name = $request->query('name');
        $brand = $request->query('brand');
        $min_price = $request->query("min_price");
        $max_price = $request->query("max_price");
        $cpu = $request->query('cpu');
        $display_size = $request->query('display_size');
        $gpu = $request->query('gpu');
        $hdd = $request->query('hdd');
        $motherboards = $request->query('motherboards');
        $ram = $request->query('ram');
        $ssd = $request->query('ssd');
        $hidden = $request->query('hidden');


        if ($cate_slug === 'Laptops' || $cate_slug === 'laptops') {
            $laptop_query_set = Laptop::query();
            $laptop_query_set->whereHas('product', function ($laptop_query_set) use ($hidden) {
                $laptop_query_set->where("hidden", '0');});
            if ($cpu !== null)
                $laptop_query_set->where('cpu', $cpu);

            if ($display_size !== null)
                $laptop_query_set->where('display_size', $display_size);

            if ($gpu !== null)
                $laptop_query_set->where('gpu', $gpu);

            if ($hdd !== null)
                $laptop_query_set->where('hdd', $hdd);

            if ($motherboards !== null)
                $laptop_query_set->where('motherboards', $motherboards);

            if ($ram !== null)
                $laptop_query_set->where('ram', $ram);

            if ($ssd !== null)
                $laptop_query_set->where('ssd', $ssd);

            if ($product_name !== null)
                $laptop_query_set->whereHas('product', function ($laptop_query_set) use ($product_name) {
                    $laptop_query_set->where('name', 'LIKE', "%{$product_name}%");
                });

            if ($brand !== null)
                $laptop_query_set->whereHas('product', function ($laptop_query_set) use ($brand) {
                    $laptop_query_set->where('brand', $brand);
                });

            if ($min_price !== null)
                $laptop_query_set->whereHas('product', function ($laptop_query_set) use ($min_price) {
                    $laptop_query_set->where('original_price', '>=', $min_price);
                });

            if ($max_price !== null)
                $laptop_query_set->whereHas('product', function ($laptop_query_set) use ($max_price) {
                    $laptop_query_set->where('original_price', '<=', $max_price);
                });
            $laptops = $laptop_query_set->get();
            if ($laptops != []) {
                $laptops->load('product', 'product.category');
            }

            return response()->json([
                'results' => $laptops
            ], 200);
        }

        $category = Category::where('slug', $cate_slug)->first();
        $query_set = Product::where('cate_id', $category->id)->where("hidden", '0');

        if ($product_name !== null)
            $query_set->where('name', 'LIKE', "%{$product_name}%");

        if ($brand !== null)
            $query_set->where('brand', $brand);

        if ($min_price !== null)
            $query_set->where('original_price', '>=', $min_price);

        if ($max_price !== null)
            $query_set->where('original_price', '<=', $max_price);

        $products = $query_set->get();

        if ($products != []) {
            $products->load('category');
        }

        return response()->json([
            'results' => $products
        ], 200);
    }
}
