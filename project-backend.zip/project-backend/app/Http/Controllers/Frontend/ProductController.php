<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function products(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => ['sometimes', 'max:255'],
            'brand' => ['sometimes', 'string', 'max:255'],
            'min_price' => ['sometimes', 'integer', 'min:0'],
            'max_price' => ['sometimes', 'integer', 'min:0'],
        ], [
            'name.string' => 'The name must be a string.',
            'name.max' => 'The name may not be greater than 255 characters.',
            'brand.string' => 'The brand must be a string.',
            'brand.max' => 'The brand may not be greater than 255 characters.',
            'min_price.integer' => 'The minimum price must be an integer.',
            'min_price.min' => 'The minimum price must be at least 0.',
            'max_price.integer' => 'The max price must be an integer.',
            'max_price.min' => 'The max price must be at least 0.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $product_name = $request->query('name');
        $brand = $request->query('brand');
        $cate_id = $request->query('cate_id');
        $min_price = $request->query("min_price");
        $max_price = $request->query("max_price");

        $query_set = Product::where("hidden", '0');

        if ($product_name)
            $query_set->where(function ($query) use ($product_name) {
                $query->where('name', 'LIKE', "%{$product_name}%")
                    ->orWhere('brand', 'LIKE', "%{$product_name}%");
            });

        if ($brand)
            $query_set->where('brand', $brand);

        if ($cate_id)
            $query_set->where('cate_id', $cate_id);

        if ($min_price)
            $query_set->where(function ($query) use ($min_price) {
                $query->where(function ($query) use ($min_price) {
                    $query->where('discount_price', '>', 0)
                        ->where('discount_price', '>=', $min_price);
                })->orWhere(function ($query) use ($min_price) {
                    $query->where('discount_price', '=', 0)
                        ->where('original_price', '>=', $min_price);
                });
            });

        if ($max_price)
            $query_set->where(function ($query) use ($max_price) {
                $query->where(function ($query) use ($max_price) {
                    $query->where('discount_price', '>', 0)
                        ->where('discount_price', '<=', $max_price);
                })->orWhere(function ($query) use ($max_price) {
                    $query->where('discount_price', '=', 0)
                        ->where('original_price', '<=', $max_price);
                });
            });

        $products = $query_set->get();

        if ($products != []) {
            $products->load('category');
        }

        return response()->json([
            'results' => $products
        ], 200);
    }

    public function featuredProducts()
    {
        $featured_products = Product::where('trending', '1')->where('hidden', '0')->take(10)->get();
        return response()->json([
            'results' => $featured_products
        ], 200);
    }

    public function retrieve($id)
    {
        $product = Product::with('laptops')->where("hidden",'0')->find($id);
        $product->load('category');
        return response()->json([
            'results' => $product
        ], 200);
    }

    public function brandsList(Request $request)
    {
        $cate_slug = $request->query('cate_slug');

        $query = Product::select("brand")->where("hidden", '0');

        if ($cate_slug) {
            $category = Category::where('slug', $cate_slug)->first();
            $query->where('cate_id', $category->id);
        }

        $products = $query->distinct()->get();


        return response()->json([
            'results' => $products
        ], 200);
    }
}
