<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    public function index()
    {
        $cartItems = Cart::where('user_id', Auth::id())->whereHas('products', function($query) {
            $query->where("hidden",'0');
        })->get();
        $cartItems->load('products', 'products.category');
        return response()->json([
            'results' => $cartItems
        ], 200);
    }

    public function addProduct(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'product_qty' => ['required', 'integer', 'min:1', 'max:10'],
        ], [
            'product_id.required' => 'The product ID field is required.',
            'product_id.integer' => 'The product ID must be an integer.',
            'product_id.exists' => 'The selected product ID is invalid.',
            'product_qty.required' => 'The product quantity field is required.',
            'product_qty.integer' => 'The product quantity must be an integer.',
            'product_qty.min' => 'The product quantity must be at least 1.',
            'product_qty.max' => 'The product quantity must not be greater than 10.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $product_id = $request->input(('product_id'));
        $product_qty = $request->input(('product_qty'));

        if (Auth::check()) {
            $product = Product::where('id', $product_id)->first();

            if ($product) {
                if (Cart::where('prod_id', $product_id)->where('user_id', Auth::id())->exists()) {
                    return response()->json(['status' => $product->name . " Already added to cart"], 400);
                } else {
                    $cartItem = new Cart();
                    $cartItem->prod_id = $product_id;
                    $cartItem->user_id = Auth::id();
                    $cartItem->prod_qty = $product_qty;
                    $cartItem->save();
                    return response()->json(
                        [
                            'status' => $product->name . " Added to Cart Sucsessfully",
                            'count' => Cart::where('user_id', Auth::id())->count()
                        ],
                        200
                    );
                }
                return response()->json(['status' => "Failed"], 400);
            }
        } else {
            return response()->json(['status' => "Unauthenticated"], 401);
        }
    }

    public function deleteProduct(Request $request)
    {
        if (Auth::check()) {
            $prod_id = $request->input('prod_id');
            if (Cart::where('prod_id', $prod_id)->where('user_id', Auth::id())->exists()); {
                $cartItem = Cart::where('prod_id', $prod_id)->where('user_id', Auth::id())->first();
                $cartItem->delete();
                return response()->json(['status' => "Product Deleted Successfully"]);
            }
        } else {
            return response()->json(['status' => "Login to Continue"]);
        }
    }

    public function updateCart(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'prod_id' => ['sometimes', 'required', 'integer', 'exists:products,id'],
            'prod_qty' => ['sometimes', 'required', 'integer', 'min:1', 'max:10'],
        ], [
            'prod_id.required' => 'The product ID field is required.',
            'prod_id.integer' => 'The product ID must be an integer.',
            'prod_id.exists' => 'The selected product ID is invalid.',
            'prod_qty.required' => 'The product quantity field is required.',
            'prod_qty.integer' => 'The product quantity must be an integer.',
            'prod_qty.min' => 'The product quantity must be at least 1.',
            'product_qty.max' => 'The product quantity must not be greater than 10.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        $prod_id = $request->input('prod_id');
        $product_qty = $request->input('prod_qty');

        if (Auth::check()) {
            if (Cart::where('prod_id', $prod_id)->where('user_id', Auth::id())->exists()) {
                $cart = Cart::where('prod_id', $prod_id)->where('user_id', Auth::id())->first();
                $cart->prod_qty = $product_qty;
                $cart->update();
                return response()->json([
                    'results' => $cart
                ], 200);
            }
        }
    }
}
