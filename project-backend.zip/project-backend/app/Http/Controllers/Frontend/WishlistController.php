<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Wishlist;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WishlistController extends Controller
{
    public function index()
    {
        $wishlist = Wishlist::where('user_id', Auth::id())->whereHas('products', function($query) {
            $query->where("hidden",'0');
        })->get();
        $wishlist->load('products', 'products.category');
        return response()->json([
            'results' => $wishlist
        ], 200);
    }

    public function add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => ['required', 'integer', 'exists:products,id'],
        ], [
            'product_id.required' => 'The product ID field is required.',
            'product_id.integer' => 'The product ID must be an integer.',
            'product_id.exists' => 'The selected product ID is invalid.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }


        $prod_id = $request->input('product_id');

        if (Auth::check()) {
            $product = Product::where('id', $prod_id)->first();

            if ($product) {
                if (Wishlist::where('prod_id', $prod_id)->where('user_id', Auth::id())->exists()) {
                    return response()->json(['status' => $product->name . " already added to wishlist"], 400);
                }
            }
            if (Product::find($prod_id)) {
                $wish = new Wishlist();
                $wish->prod_id = $prod_id;
                $wish->user_id = Auth::id();
                $wish->save();
                return response()->json([
                    'status' => $product->name . " already added to wishlist",
                    'count' => Wishlist::where('user_id', Auth::id())->count()
                ], 200);
            } else {
                return response()->json(['status' => "Product does not exist"]);
            }
        } else {
            return response()->json(['status' => "Login to Continue"]);
        }
    }

    public function deleteItem(Request $request)
    {
        if (Auth::check()) {
            $prod_id = $request->input('prod_id');
            if (Wishlist::where('prod_id', $prod_id)->where('user_id', Auth::id())->exists()); {
                $wish = Wishlist::where('prod_id', $prod_id)->where('user_id', Auth::id())->first();
                $wish->delete();
                return response()->json(['status' => "Item Removed from Wishlist"]);
            }
        } else {
            return response()->json(['status' => "Login to Continue"]);
        }
    }
}
