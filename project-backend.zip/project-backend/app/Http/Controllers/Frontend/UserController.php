<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\User;
use App\Rules\MatchOldPassword;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function index()
    {
        $orders = Order::where('user_id', Auth::id())->get();
        return response()->json([
            'results' => $orders
        ], 200);
    }

    public function view($id)
    {
        $order = Order::where('id', $id)->where('user_id', Auth::id())->first();
        $order->load('orderitems', 'orderitems.products');
        return response()->json([
            'results' => $order
        ], 200);
    }

    public function edit(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'fname' => ['required', 'string', 'max:255'],
            'lname' => ['required', 'string', 'max:255'],
            'address1' => ['required', 'string', 'max:255'],
            'address2' => ['sometimes', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', "regex:/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/", 'max:255'],
            'country' => ['required', 'string', 'max:255'],
            'city' => ['required', 'string', 'max:255'],
            'state' => ['required', 'string', 'max:255'],
            'pincode' => ['required', 'string', 'max:255'],
        ], [
            'fname.required' => 'The first name field is required.',
            'fname.string' => 'The first name must be a string.',
            'fname.max' => 'The first name may not be greater than 255 characters.',
            'lname.required' => 'The last name field is required.',
            'lname.string' => 'The last name must be a string.',
            'lname.max' => 'The last name may not be greater than 255 characters.',
            'address1.required' => 'The address1 field is required.',
            'address1.string' => 'The address1 must be a string.',
            'address1.max' => 'The address1 may not be greater than 255 characters.',
            'address2.required' => 'The address2 field is required.',
            'address2.string' => 'The address2 must be a string.',
            'address2.max' => 'The address2 may not be greater than 255 characters.',
            'phone.required' => 'The phone number field is required.',
            'phone.string' => 'The phone number must be a string.',
            'phone.max' => 'The phone number may not be greater than 255 characters.',
            'email.required' => 'The email field is required.',
            'email.string' => 'The email must be a string.',
            'email.regex' => 'The email must be a valid email address.',
            'country.required' => 'The country field is required.',
            'country.string' => 'The country must be a string.',
            'country.max' => 'The country may not be greater than 255 characters.',
            'city.required' => 'The city field is required.',
            'city.string' => 'The city must be a string.',
            'city.max' => 'The city may not be greater than 255 characters.',
            'state.required' => 'The state field is required.',
            'state.string' => 'The state must be a string.',
            'state.max' => 'The state may not be greater than 255 characters.',
            'pincode.required' => 'The pincode field is required.',
            'pincode.string' => 'The pincode must be a string.',
            'pincode.max' => 'The pincode may not be greater than 255 characters.',
        ]);


        if ($validator->fails()) {
            return response()->json([
                'status' => $validator->errors()->first()
            ], 400);
        }

        if ($id == Auth::id()) {
            $user = User::find($id);

            $user->name = $request->input('fname');
            $user->lname = $request->input('lname');
            $user->address1 = $request->input('address1');
            $user->address2 = $request->input('address2');
            $user->phone = $request->input('phone');
            $user->email = $request->input('email');
            $user->country = $request->input('country');
            $user->city = $request->input('city');
            $user->state = $request->input('state');
            $user->pincode = $request->input('pincode');

            $user->save();

            return response()->json([
                'results' => $user
            ], 200);
        } else {
            return response()->json([
                'error' => "User Unauthenticated"
            ], 401);
        }
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'current_password' => ['required', new MatchOldPassword],
            'new_password' => ['required', 'min:8', 'different:current_password'],
            'new_confirm_password' => ['same:new_password', 'min:8', 'different:current_password'],
        ], [
            'current_password.required' => 'The current password field is required.',
            'new_password.required' => 'The new password field is required.',
            'new_password.min' => 'The new password must be at least 8 characters.',
            'new_confirm_password.same' => 'The new password and confirmation password must match.',
            'new_confirm_password.min' => 'The confirmation password must be at least 8 characters.',
            'new_password.different' => 'The new password must not be the same as the old password.',
            'new_confirm_password.different' => 'The new confirm password must not be the same as the old password.',
        ]);

        User::find(auth()->user()->id)->update(['password' => Hash::make($request->new_password)]);

        return response()->json([
            'results' => "Password Changed Susscefully"
        ], 200);
    }

    public function delete($id)
    {
        $user = User::find($id);
        $user->delete();

        return response()->json([
            'status' => "User Deleted Susscefully"
        ], 200);
    }
}
