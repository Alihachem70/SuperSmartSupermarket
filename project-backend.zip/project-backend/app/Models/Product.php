<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'products';
    protected $fillable = [
        'cate_id',
        'name',
        'small_description',
        'description',
        'original_price',
        'image',
        'qty',
        'hidden',
        'trending',
        'show_in_carousel',
    ];

    protected $dates = ['deleted_at'];

    public static function boot()
    {
        parent::boot();

        static::deleting(function (Product $product) {
            $product->carts()->delete();
            $product->wishlists()->delete();
            $product->laptops()->delete();
        });
    }

    public function wishlists()
    {
        return $this->hasMany(Wishlist::class, 'prod_id', 'id');
    }

    public function carts()
    {
        return $this->hasMany(Cart::class, 'prod_id', 'id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class, 'cate_id', 'id');
    }

    public function laptops()
    {
        return $this->hasMany(Laptop::class,'prod_id','id');
    }
}
