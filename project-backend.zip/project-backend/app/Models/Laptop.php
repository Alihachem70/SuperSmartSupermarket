<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Laptop extends Model
{
    use HasFactory;
    
    protected $table = 'laptops';
    protected $fillable = [
        'motherboard',
        'cpu',
        'gpu',
        'display_size',
        'ssd',
        'hdd',
        'ram',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class, 'prod_id', 'id');
    }
}
