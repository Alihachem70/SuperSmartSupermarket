<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::get('/trending-categories', 'Frontend\CategoryController@trendingCategories');
Route::get('categories-user', 'Frontend\CategoryController@categories');
Route::get('products-of-category/{slug}', 'Frontend\CategoryController@productsOfCategory');

Route::get('/featured-products', 'Frontend\ProductController@featuredProducts');
Route::get('all-products', 'Frontend\ProductController@products');
Route::get('all-products/{id}', 'Frontend\ProductController@retrieve');

Route::get('brands', "Frontend\ProductController@brandsList");
Route::get('laptops/specs', "Frontend\LaptopController@specsList");
Route::get('laptops',"Frontend\LaptopController@retrieve");
Route::post('login', 'AuthController@login');
Route::post('register', 'AuthController@register');
Route::post('logout', 'AuthController@logout');
Route::get('me', 'AuthController@me');

Route::middleware(['isAdmin', 'auth:api'])->group(function () {
    //categories
    Route::get('categories', 'Admin\CategoryController@index');
    Route::post('insert-category', 'Admin\CategoryController@insert');
    
    Route::get('category/{id}', 'Admin\CategoryController@retrieve');
    Route::put('update-category/{id}', 'Admin\CategoryController@update');
    
    Route::get('delete-category/{id}', 'Admin\CategoryController@destroy');
    
    //products
    Route::post('insert-product', 'Admin\ProductController@insert');
    
    Route::get('products', "Admin\ProductController@index");
    Route::get('product/{id}', 'Admin\ProductController@retrieve');
    Route::put('update-product/{id}', 'Admin\ProductController@update');
    
    Route::get('delete-product/{id}', 'Admin\ProductController@destroy');

    Route::get('orders', 'Admin\OrderController@index');
    Route::get('admin/view-order/{id}', 'Admin\OrderController@view');
    Route::put('update-order/{id}', 'Admin\OrderController@updateOrder');
    Route::get('orders-history', 'Admin\OrderController@orderHistory');

    Route::get('users', 'Admin\DashboardController@users');
    Route::get('user/{id}/delete', 'Frontend\UserController@delete');
    Route::get('user/{id}', 'Admin\DashboardController@viewUser');

    Route::get('analysis-admin', 'Frontend\AnalysisController@adminAnalysis');
});

Route::middleware(['auth:api'])->group(function () {
    Route::get('cart', 'Frontend\CartController@index');
    Route::get('wishlist', 'Frontend\WishlistController@index');

    Route::post('add-to-cart', 'Frontend\CartController@addProduct');
    Route::post('delete-cart-item', 'Frontend\CartController@deleteProduct');
    Route::post('update-cart', 'Frontend\CartController@updateCart');

    Route::post('add-to-wishlist', 'Frontend\WishlistController@add');
    Route::post('delete-wishlist-item', 'Frontend\WishlistController@deleteItem');

    Route::get('my-orders', 'Frontend\UserController@index');
    Route::get('view-order/{id}', 'Frontend\UserController@view');
    Route::get('analysis-user', 'Frontend\AnalysisController@userAnalysis');

    Route::put('user/{id}/edit', 'Frontend\UserController@edit');
    Route::post('user/{id}/change-password', 'Frontend\UserController@changePassword');
    Route::post('place-order', 'Frontend\CheckoutController@placeOrder');

});

